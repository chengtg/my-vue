<template>
  <fm-making-form></fm-making-form>
</template>

<script>
  // import fm-making-form from './components/Container.vue'
  // import FormMaking from './index';
  //
  //
  // Vue.use(FormMaking);
  export default {
    // components: {
    //   fm-making-form
    //}
  }
</script>
