<template>
  <fm-making-form></fm-making-form>
</template>

<script>
export default {
}
</script>
